(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['pfafman:font-awesome-4'] = {};

})();

//# sourceMappingURL=pfafman_font-awesome-4.js.map
