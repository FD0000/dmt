(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['peernohell:c3'] = {};

})();

//# sourceMappingURL=peernohell_c3.js.map
