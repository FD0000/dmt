(function(){//document.addEventListener('DOMContentLoaded', function(e){
//  console.log('Hello world!');
//});
//
//var bigData = [];
//var user = Meteor.user()._id;
//bigData.push(user);

})();
